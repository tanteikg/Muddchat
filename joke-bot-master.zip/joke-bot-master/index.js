'use strict'

require('./app/')(require('./config/')())
